package com.salesforce.citi.connector.execute;

import org.apache.kafka.clients.producer.KafkaProducer;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Properties;

public class KafkaProducerCiti {

	public static void SendSalesForceDataToKafkaTopic(String jsonData) {
		Properties properties = new Properties();
	
		
		//System.out.print(((JSONObject)SalesForceConnect.configdata.get("KAFKA")).get("BOOTSTRAP_SERVERS").toString());
		JSONArray jsonArray= (JSONArray)Utilities.configdata.get("KAFKA");
		JSONObject jsonObject=((JSONObject)jsonArray.get(0));
		
		properties.put("bootstrap.servers", jsonObject.get("BOOTSTRAP_SERVERS").toString());
		properties.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		properties.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		//////////////////////// With SSL Code
	
//		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
//
//		//configure the following three settings for SSL Encryption
//		properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
//		properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.truststore.jks");
//		properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,  "");
//
//		// configure the following three settings for SSL Authentication
//		properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "/var/private/ssl/kafka.client.keystore.jks");
//		properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "test1234");
//		properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "test1234");
//
//		properties.put(ProducerConfig.ACKS_CONFIG, "all");
//		properties.put(ProducerConfig.RETRIES_CONFIG, 0);
//		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");
//		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringSerializer");

		
		///////////////////////////
		
		KafkaProducer<String, String> kafkaProducer =null;
		try {
		kafkaProducer = new KafkaProducer<String, String>(properties);
		kafkaProducer.send(new ProducerRecord<String, String>(
				jsonObject.get("TOPIC").toString(),jsonObject.get("TOPIC_KEY").toString(),jsonData.toString()));
		}catch (Exception e){
            e.printStackTrace();
        }finally {
            kafkaProducer.close();
        }

	}
  
	public static void  WriteCSVDataToHDFSFromString(String data) {

	
//	    spark = SparkSession.builder.appName("Stremaing_SalesForceToHDFS").getOrCreate()        
//	    spark.sparkContext.setLogLevel("WARN")
//	    json_list =[]
//	    json_list.append(data)
//	    df = spark.read.csv(spark.sparkContext.parallelize(json_list))
//	    
//	    df.show()
//	    #df.write.csv("hdfs://localhost:9000/KafkaSalesData/example.csv")
//	    Index=GetItemIndex(configdata['SEARCH_STRING_FOR_INDEX']['HDFS_SERARCH_1']) 
//	    df.write.csv(configdata['HDFS'][Index]['URL']+configdata['HDFS'][Index]['HDFS_FILE_PATH']+"FileFromSparkCSV_"+datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
//	    #print(configdata)
	}
	
    public static void main(String[] args){
    	new SalesForceConnect();
    	//socketConnection();
    	//SendSalesForceDataToKafkaTopic("test1234");
    }
}

 
 