package com.salesforce.citi.connector.execute;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.jasypt.util.text.BasicTextEncryptor;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mysql.cj.xdevapi.JsonArray;

import oracle.jdbc.driver.json.tree.JsonpObjectImpl;

//##################################Get Application Resources From Properties File ##################################
class ReadResourceDataFromJar{
	

	public  Properties getApplicationResourcesJar() {
		Properties propertiesRes=null;
		try {
			
			InputStream is = this.getClass().getClassLoader().getResourceAsStream("applicationResources.properties");
			propertiesRes=new Properties();
			propertiesRes.load(is);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//String appPropertFile=propertiesRes.getProperty("PropertiesFilePath");
		//System.out.println(appPropertFile+"=>"+propertiesRes.getProperty("EnvironmentSetupFile"));

		return propertiesRes;
	}	
}
public class Utilities {
	public static JSONObject configdata;
	public static FileWriter logWriter;
	public Utilities() {
		configdata= Utilities.getApplicationConfiguration();
		logWriter=Utilities.setProcessLogConfiguration();
	}
	

	
	//##################################Get Application Properties From Properties File ##################################
	
	public static Properties getApplicationProperties() {
		FileReader reader = null;
		ReadResourceDataFromJar readFromJar=new ReadResourceDataFromJar();
	
		System.out.println("Callling ...."+readFromJar.getApplicationResourcesJar().getProperty("PropertiesFilePath")+"=>"+readFromJar.getApplicationResourcesJar().getProperty("EnvironmentSetupFile"));
		try {
		
			//reader = new FileReader("Application.properties");
			reader = new FileReader(readFromJar.getApplicationResourcesJar().getProperty("PropertiesFilePath"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Properties properties=new Properties();  
		try {
			properties.load(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return properties;
	}

	//##################################Get Application Configuration From Json File ##################################


	public static JSONObject getApplicationConfiguration() {

		String FilePathAndName =getApplicationProperties().getProperty("ConfigFileName");

		BufferedReader bufferedReader = null;
		try {
			bufferedReader = Files.newBufferedReader(Paths.get(FilePathAndName));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String curLine=null;
		String FileContent="";
		try {
			while ((curLine = bufferedReader.readLine()) != null){
				FileContent=FileContent.concat(curLine);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bufferedReader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JSONObject jsonObject = new JSONObject(FileContent);
		return jsonObject;

	}

	//############################Parse Json Object#############################
	public static String getJsonValue(String jsonReq, String key) {
		JSONObject json = new JSONObject(jsonReq);
		boolean exists = json.has(key);
		Iterator<?> keys;
		String nextKeys;
		String val = "";
		if (!exists) {
			keys = json.keys();
			while (keys.hasNext()) {
				nextKeys = (String) keys.next();
				try {
					if (json.get(nextKeys) instanceof JSONObject) {
						return getJsonValue(json.getJSONObject(nextKeys).toString(), key);
					} else if (json.get(nextKeys) instanceof JSONArray) {
						JSONArray jsonArray = json.getJSONArray(nextKeys);
						int i = 0;
						if (i < jsonArray.length()) do {
							String jsonArrayString = jsonArray.get(i).toString();
							JSONObject innerJson = new JSONObject(jsonArrayString);
							return getJsonValue(innerJson.toString(),key);
						} while (i < jsonArray.length());
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {
			val = json.get(key).toString();
		}
		return val;
	}

	//####################### Print Log Message###############################	
	public static void logMessageInProcessLog(String LogMessage) {	

		if (((JSONObject)configdata.get("PROCESS_LOG")).get("ENABLE_FILE_LOGGING").toString().toUpperCase().equals("YES"))
			//logger.log(System.Logger.Level.WARNING, LogMessage);
			try {
				logWriter.write(LogMessage+"\n");
				logWriter.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		if (((JSONObject)configdata.get("PROCESS_LOG")).get("PRINT_LOG_MESSGAE_ON_CONSOLE").toString().toUpperCase().equals("YES")) {
			System.out.println(LogMessage);
		}
	}

	public static FileWriter setProcessLogConfiguration() {
		String LogFilePath=((JSONObject)configdata.get("SYSTEM_PARAMETERS")).get("LOCAL_FILE_PATH")+File.separator+"Logs"+File.separator;

		//Delete Old Log Files which are more than LOG_FILE_RETENTION_PERIOD Old


		File logFileDir=new File(LogFilePath);
		if (!logFileDir.exists()){
			logFileDir.mkdirs();	
		}

		for (String file : logFileDir.list()) {
			// Print the names of files and directories
			//System.out.println(file);

			Path filepath = Paths.get(logFileDir+File.separator+file);
			//System.out.println(filepath);
			BasicFileAttributes attr;
			try {
				attr = Files.readAttributes(filepath, BasicFileAttributes.class);

				int FileRetentionDays=(int) ((JSONObject)configdata.get("PROCESS_LOG")).get("LOG_FILE_RETENTION_PERIOD");

				long curMiliSecs=new Date().getTime();
				int fileCreatedDayBefore=(int) (curMiliSecs - attr.creationTime().toMillis())/(86400*1000);

				//System.out.println(attr.creationTime().toMillis()+ "\nCurtime.."+curMiliSecs + "   " +attr.creationTime().toMillis()+" "+fileCreatedDayBefore);

				if (fileCreatedDayBefore >=FileRetentionDays ){
					System.out.println("Deleting File.....< "+filepath +" >  Since This is more than....< " +FileRetentionDays+" > Old");
					Files.delete(filepath);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		}

		String logFileName=LogFilePath+((JSONObject)configdata.get("PROCESS_LOG")).get("LOG_FILE_NAME")+"_"+getTimeInFormat("yyyyMMdd")+".log";

		File logFile=new File(logFileName);

		FileWriter fileWriter=null;

		if (!logFile.exists()) {
			try {
				logFile.createNewFile();		
				fileWriter = new FileWriter(logFileName);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			try {
				fileWriter = new FileWriter(logFileName,true);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return fileWriter;
	}

	public  static String getTimeInFormat(String TimeFormat) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(TimeFormat);
		Date now = new Date();
		return dateFormat.format(now);
	}

	public static Connection getDataBaseConnection(String dbType){  
		Connection dbConnection=null;
		try{ 
			JSONObject configdata=getApplicationConfiguration();
			JSONObject dbconfdata=((JSONObject)((JSONArray)((JSONObject)configdata.get("DATABASE")).get(dbType)).get(0));
			Class.forName(dbconfdata.get("DRIVER").toString());  
			dbConnection=DriverManager.getConnection(dbconfdata.get("SERVER").toString()+
					dbconfdata.get("DBNAME").toString(),dbconfdata.get("USERNAME").toString(),
					dbconfdata.get("PASSWORD").toString());    
		}catch(Exception e)
		{ 
			System.out.println(e);
		}  
		return dbConnection;
	}  


	public static List<JSONObject> getQueryResult(Connection connection,String selectQuery){  
		String querResult="";
		List<JSONObject> jsonArray=new  ArrayList<JSONObject>();

		Statement stmt=null;
		try {
			stmt = connection.createStatement();

			ResultSet rs=stmt.executeQuery(selectQuery); 
			ResultSetMetaData rsmd = rs.getMetaData();

			while(rs.next()) {
				int i =1;
				JSONObject jsonObject =new JSONObject();
				while (i<=rsmd.getColumnCount()) {
					jsonObject.put(rsmd.getColumnName(i), rs.getObject(i));						
					querResult+=rs.getObject(i)+" # ";
					if (i==rsmd.getColumnCount()) {
						jsonArray.add(jsonObject);
						//System.out.println(jsonArray);
						querResult+="\n";
					}
					i+=1;
				}
			}
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println(jsonArray);
		//System.out.println(querResult);
		return jsonArray;
	} 
	public static BasicTextEncryptor initEncryptDecrypt() {
		BasicTextEncryptor bte = new BasicTextEncryptor();
		bte.setPassword("RandomTextForCiti#178367376");	
		return bte;
	}
	public static String ecryptPassword(BasicTextEncryptor bte ,String plainPassword) {
		return bte.encrypt(plainPassword);
	}
	public static String decryptPassword(BasicTextEncryptor bte ,String encryptedPAssword) {
	
		return bte.decrypt(encryptedPAssword);
	}
   
}
