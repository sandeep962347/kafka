/*
 * Copyright (c) 2016, salesforce.com, inc.
 * All rights reserved.
 * Licensed under the BSD 3-Clause license.
 * For full license text, see LICENSE.TXT file in the repo root  or https://opensource.org/licenses/BSD-3-Clause
 */
package com.salesforce.citi.connector.execute;

import com.salesforce.citi.connector.BayeuxParameters;
import com.salesforce.citi.connector.EmpConnector;
import com.salesforce.citi.connector.TopicSubscription;

import java.util.Map;
import java.util.concurrent.*;
import java.util.function.Consumer;
import org.eclipse.jetty.util.ajax.JSON;
import org.json.JSONObject;

import static com.salesforce.citi.connector.LoginHelper.login;
import static org.cometd.bayeux.Channel.*;

/**
 * An example of using the EMP connector
 *
 * @author hal.hildebrand
 * @since API v37.0
 */
public class SalesForceStreamCDCLogin {

    // More than one thread can be used in the thread pool which leads to parallel processing of events which may be acceptable by the application
    // The main purpose of asynchronous event processing is to make sure that client is able to perform /meta/connect requests which keeps the session alive on the server side
    private final ExecutorService workerThreadPool = Executors.newFixedThreadPool(1);

    public static void main(String[] argv) throws Throwable {
        SalesForceStreamCDCLogin devLoginExample = new SalesForceStreamCDCLogin();
        devLoginExample.processEvents(argv);
    }


    public void processEvents(String[] argv) throws Throwable {
   
    	SalesForceConnect salesForceConnect=new SalesForceConnect();  //call constructor to initialize application configuration
    	
		JSONObject jobectForOauth=	((JSONObject)((JSONObject) Utilities.configdata.get("SALESFORCE")).get("AUTHENTICATION"));		

        BearerTokenProvider tokenProvider = new BearerTokenProvider(() -> {
            try {
        		
            	if (((JSONObject)Utilities.configdata.get("SYSTEM_PARAMETERS")).get("CREDENTIAL").equals("SYSTEM_ENVIRONMENT")) {
        			jobectForOauth.put("Password", Utilities.getApplicationProperties().getProperty("SalesForcePassword"));
        		}		
        		
                return login(jobectForOauth.get("UserName").toString(), jobectForOauth.get("Password").toString());
            } catch (Exception e) {
                e.printStackTrace(System.err);
                System.exit(1);
                throw new RuntimeException(e);
            }
        });
        
        BayeuxParameters params = tokenProvider.login();

        EmpConnector connector = new EmpConnector(params);
        LoggingListener loggingListener = new LoggingListener(true, true);

        connector.addListener(META_HANDSHAKE, loggingListener)
                .addListener(META_CONNECT, loggingListener)
                .addListener(META_DISCONNECT, loggingListener)
                .addListener(META_SUBSCRIBE, loggingListener)
                .addListener(META_UNSUBSCRIBE, loggingListener);

        connector.setBearerTokenProvider(tokenProvider);

        connector.start().get(5, TimeUnit.SECONDS);

        long replayFrom = EmpConnector.REPLAY_FROM_TIP;
       
        TopicSubscription subscription;
        try {
            subscription = connector.subscribe("/data/ChangeEvents", replayFrom, getConsumer()).get(5, TimeUnit.SECONDS);
        } catch (ExecutionException e) {
            System.err.println(e.getCause().toString());
            System.exit(1);
            throw e.getCause();
        } catch (TimeoutException e) {
            System.err.println("Timed out subscribing");
            System.exit(1);
            throw e.getCause();
        }

        System.out.println(String.format("Subscribed: %s", subscription));
    }

    public void GetDataFromSalesForceCDC(String Data) {
    	SalesForceConnect salesForceConnect=new SalesForceConnect(); //To refresh config data if any changes in config file - on the fly changes ---experimental
    	Utilities.logMessageInProcessLog("Data From Salesforce......"+Data);
    	SalesForceConnect.processSalesForceData(Data);    	
    }
    
    public Consumer<Map<String, Object>> getConsumer() {
    	//return event -> workerThreadPool.submit(() -> System.out.println(String.format("Received:\n%s, \nEvent processed by threadName:%s, threadId: %s", JSON.toString(event), Thread.currentThread().getName(), Thread.currentThread().getId())));
        
    	return event -> workerThreadPool.submit(() -> GetDataFromSalesForceCDC( JSON.toString(event)));
    }
}
