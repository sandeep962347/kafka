/* Copyright (c) 2016, salesforce.com, inc. All rights reserved. Licensed under the BSD 3-Clause license. For full
 * license text, see LICENSE.TXT file in the repo root or https://opensource.org/licenses/BSD-3-Clause
 */
package com.salesforce.citi.connector.execute;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import com.salesforce.citi.connector.BayeuxParameters;
import com.salesforce.citi.connector.EmpConnector;
import com.salesforce.citi.connector.TopicSubscription;
import org.cometd.bayeux.Channel;
import org.eclipse.jetty.util.ajax.JSON;
import org.json.JSONObject;

/**
 * An example of using the EMP connector using bearer tokens
 *
 * @author Kamlesh Pant
 * @since API v37.0
 */
public class SalesForceStreamCDCToken {
    // More than one thread can be used in the thread pool which leads to parallel processing of events which may be acceptable by the application
    // The main purpose of asynchronous event processing is to make sure that client is able to perform /meta/connect requests which keeps the session alive on the server side
	
	
	private static final ExecutorService workerThreadPool = Executors.newFixedThreadPool(1);

    public static void GetDataFromSalesForceCDC(String Data) {
    	SalesForceConnect salesForceConnect=new SalesForceConnect(); //To refresh config data if any changes in config file - on the fly changes ---experimental
    	Utilities.logMessageInProcessLog("Data From Salesforce......"+Data);
    	SalesForceConnect.processSalesForceData(Data);    	
    }

    public static void main(String[] argv) throws Exception {
    	
    	SalesForceConnect salesForceConnect=new SalesForceConnect();//call constructor to initialize application configuration
    	
    	long replayFrom = EmpConnector.REPLAY_FROM_TIP;

        BayeuxParameters params = new BayeuxParameters() {

            @Override
            public String bearerToken() {
                return SalesForceConnect.getAccessToken();
            }

            @Override
            public URL host() {
                try {
                    return new URL(((JSONObject)Utilities.configdata.get("SALESFORCE")).get("DomainURL").toString());
                } catch (MalformedURLException e) {
                    throw new IllegalArgumentException(String.format("Unable to create url: %s", argv[0]), e);
                }
            }
        };

       // Consumer<Map<String, Object>> consumer = event -> workerThreadPool.submit(() -> System.out.println(String.format("Received:\n%s, \nEvent processed by threadName:%s, threadId: %s", JSON.toString(event), Thread.currentThread().getName(), Thread.currentThread().getId())));
        Consumer<Map<String, Object>> consumer = event -> workerThreadPool.submit(() -> GetDataFromSalesForceCDC( JSON.toString(event)));
        
        EmpConnector connector = new EmpConnector(params);

        connector.addListener(Channel.META_CONNECT, new LoggingListener(true, true))
        .addListener(Channel.META_DISCONNECT, new LoggingListener(true, true))
        .addListener(Channel.META_HANDSHAKE, new LoggingListener(true, true));

        connector.start().get(5, TimeUnit.SECONDS);

        TopicSubscription subscription = connector.subscribe("/data/ChangeEvents", replayFrom, consumer).get(5, TimeUnit.SECONDS);
        
               
      //TopicSubscription subscription = connector.subscribe("/event/Opportunity_Event__e", replayFrom, consumer).get(5, TimeUnit.SECONDS);
        

        System.out.println(String.format("Subscribed: %s", subscription));
    }
}
