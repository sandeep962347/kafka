package com.salesforce.citi.connector.execute;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.sql.Connection;
import java.util.Properties;

//import javax.rmi.CORBA.Util;

import org.jasypt.util.text.BasicTextEncryptor;
import org.json.JSONArray;
import org.json.JSONObject;

public class SalesForceConnect {
	//private Logger logger;
    static String salesForcePlatformEvent;
	public SalesForceConnect() {
		Utilities util=new Utilities();
	}

	//##################################Get Access Token ##################################

	public static String getAccessToken() {
		Properties property=Utilities.getApplicationProperties();
		Utilities.logMessageInProcessLog("accessToken.....");
		String AccessToken=null;

		// logger.debug("Timeout: {}", connection.getConnectTimeout());		


		try {

			JSONObject jobectForOauth=	((JSONObject)((JSONObject) Utilities.configdata.get("SALESFORCE")).get("AUTHENTICATION"));

			if (((JSONObject)Utilities.configdata.get("SYSTEM_PARAMETERS")).get("CREDENTIAL").equals("SYSTEM_ENVIRONMENT")) {
				jobectForOauth.put("Password", property.getProperty("SalesForcePassword"));
				jobectForOauth.put("ClientSecret", property.getProperty("SalesForceClientSecret"));
			}

			URL urlForPsotRequest  =new URL(jobectForOauth.get("AuthURL")
					+ "username="+		jobectForOauth.get("UserName")
					+ "&password="+		jobectForOauth.get("Password")
					+ "&grant_type="+	jobectForOauth.get("GrantType")
					+ "&client_id="+	jobectForOauth.get("ClientID")
					+ "&client_secret="+jobectForOauth.get("ClientSecret"));
			System.out.print(urlForPsotRequest);
			//System.exit(0);
			HttpURLConnection connection = null;
			if (jobectForOauth.get("WebProxy").toString().length()>0) {
				InetAddress webproxyip = InetAddress.getByName(new URL(jobectForOauth.get("WebProxy").toString()).getHost());				
				Utilities.logMessageInProcessLog("webproxyip....."+webproxyip.getHostAddress());
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(webproxyip.getHostAddress(), 8080));			
				connection = (HttpURLConnection) urlForPsotRequest.openConnection(proxy);
			}
			else
				connection = (HttpURLConnection) urlForPsotRequest.openConnection();

			connection.addRequestProperty("Accept", "application/json");
			connection.addRequestProperty("Content-Type" , "application/json;utf-8");

			connection.setRequestMethod("POST");
			int responseCode = connection.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

				StringBuffer response = new StringBuffer();
				String readLine;
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				String responseString = response.toString();

				AccessToken= new JSONObject(responseString).get("access_token").toString();
				System.out.println(AccessToken);		    	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return AccessToken;
	}


	//##################################Get Request Call ##################################

	static JSONObject getRequest(String EndPointURL) {		
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		String responseString=null;
		URL urlForGetRequest;
		try {
			urlForGetRequest = new URL(EndPointURL);

			JSONObject jobectForOauth=	((JSONObject)((JSONObject) Utilities.configdata.get("SALESFORCE")).get("AUTHENTICATION"));
			HttpURLConnection connection = null;
			if (jobectForOauth.get("WebProxy").toString().length()>0) {
				InetAddress webproxyip = InetAddress.getByName(new URL(jobectForOauth.get("WebProxy").toString()).getHost());
				Utilities.logMessageInProcessLog(webproxyip.toString());
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(webproxyip.getHostAddress(), 8080));			
				connection = (HttpURLConnection) urlForGetRequest.openConnection(proxy);

			}
			else
				connection = (HttpURLConnection) urlForGetRequest.openConnection();

			connection.addRequestProperty("Authorization","Bearer "+getAccessToken());
			connection.addRequestProperty("Content-Type" , "application/json;utf-8");
			connection.setRequestMethod("GET");

			int responseCode = connection.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

				StringBuffer response = new StringBuffer();
				String readLine;
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				responseString = response.toString();
				Utilities.logMessageInProcessLog("response...."+responseString+"\n");

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jsonObject = new JSONObject(responseString);
		//System.out.print(jsonObject);
		return jsonObject;
	}

	//
	//	//##################################Post Request Call ##################################
	//
	static JSONObject postRequest(String EndPointURL,JSONObject BodyDetails) {		
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		String responseString=null;
		URL urlForPostRequest;
		try {
			urlForPostRequest = new URL(EndPointURL);

			JSONObject jobectForOauth=	((JSONObject)((JSONObject) Utilities.configdata.get("SALESFORCE")).get("AUTHENTICATION"));
			HttpURLConnection connection = null;
			if (jobectForOauth.get("WebProxy").toString().length()>0) {
				InetAddress webproxyip = InetAddress.getByName(new URL(jobectForOauth.get("WebProxy").toString()).getHost());
				Utilities.logMessageInProcessLog(webproxyip.toString());
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(webproxyip.getHostAddress(), 8080));				
				connection = (HttpURLConnection) urlForPostRequest.openConnection(proxy);

			}
			else
				connection = (HttpURLConnection) urlForPostRequest.openConnection();

			connection.addRequestProperty("Authorization","Bearer "+getAccessToken());
			connection.addRequestProperty("Content-Type" , "application/json; utf-8");
			connection.setRequestMethod("POST");

			try(OutputStream os = connection.getOutputStream()) {
				byte[] input = BodyDetails.toString().getBytes("utf-8");
				os.write(input, 0, input.length);			
			}

			int responseCode = connection.getResponseCode();
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));

				StringBuffer response = new StringBuffer();
				String readLine;
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				responseString = response.toString();
				Utilities.logMessageInProcessLog("response...."+responseString+"\n");

			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JSONObject jsonObject = new JSONObject(responseString);
		//System.out.print(jsonObject);
		return jsonObject;
	}


	//	//##################################Get Request Call And Returns Json Array ##################################

	public static JSONArray getJsonArrayFromSaleForceObject(String EndPointURL) {
		JSONObject jsobject= getRequest(EndPointURL);
		System.out.println(jsobject);
		JSONArray ArrayData=(JSONArray)jsobject.getJSONArray("records");
		for(int i = 0; i < ArrayData.length(); i++)
		{
			System.out.println(((JSONObject)ArrayData.get(i)).get("Name"));
		}

		return ArrayData;
	}
	//
	//	//##################################Get Request GetDataFromSalesForceRestAPI ##################################

	public static JSONObject getDataFromSalesForceRestAPI(String ApiName) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jobject=((JSONObject)
				((JSONObject)
						((JSONObject) 
								Utilities.configdata.get("SALESFORCE")).get("GETAPI")	).get(ApiName));

		String EndPointURL=(String) jobject.get("EndPointURL")+jobject.get("QueryOrHeaderParameters");

		return getRequest(EndPointURL);
	}

	//	//##################################Post Request PostDataToSalesForceRestAPI ##################################

	public static JSONObject postDataToSalesForceRestAPI(String ApiName,JSONObject BodyDetails) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jobject=((JSONObject)
				((JSONObject)
						((JSONObject) 
								Utilities.configdata.get("SALESFORCE")).get("POSTAPI")).get(ApiName));

		String EndPointURL=(String) jobject.get("EndPointURL")+jobject.get("QueryOrHeaderParameters");
		return postRequest(EndPointURL, BodyDetails);
	}

	//	//###########################Process Data Which is Received From SalesForce###################################

	public static void processSalesForceDataOld(String salesForceData) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jsonObject=new JSONObject(salesForceData);
		String salesForceEntity=((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("entityName").toString();

		if (salesForceEntity.toUpperCase().equals("USER")) {
			Utilities.logMessageInProcessLog("\n##################User Changes#############################\n");
			JSONArray recordIds=(JSONArray)((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("recordIds");
			int uid=0;

			while (uid < recordIds.length()) {				
				//String URLEndPoint=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetUserDataWithUserRole")).get("EndPointURL").toString(); //+salesForceEntity+"/"+recordIds.get(uid);
				String newJoinQuery=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetUserDataWithUserRole")).get("QueryOrHeaderParameters").toString()+"+and+"+salesForceEntity+".id='"+recordIds.get(uid)+"'";	
				//Calling Direct Get APi Call
				//jsonObject.put("UserWithRoles",getRequest(URLEndPoint+newJoinQuery));
				Utilities.logMessageInProcessLog("Query String..."+newJoinQuery);
				//update QueryOrHeaderParameters with user and condition
				((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetUserDataWithUserRole")).put("QueryOrHeaderParameters",newJoinQuery);

				jsonObject.put("UserWithRoles",getDataFromSalesForceRestAPI("GetUserDataWithUserRole"));
				uid+=1;
			}		

			//System.out.println(jsonObject);
			Utilities.logMessageInProcessLog(jsonObject.toString());
		}

		if (salesForceEntity.toUpperCase().equals("ACCOUNT")) {

			Utilities.logMessageInProcessLog("\n##################Account Changes#############################\n");
			JSONArray recordIds=(JSONArray)((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("recordIds");
			int uid=0;

			while (uid < recordIds.length()) {				
				//String URLEndPoint=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetAccountWithAccountShare")).get("EndPointURL").toString(); //+salesForceEntity+"/"+recordIds.get(uid);
				String newJoinQuery=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetAccountWithAccountShare")).get("QueryOrHeaderParameters").toString()+"+and+"+salesForceEntity+".id='"+recordIds.get(uid)+"'";	
				//Calling Direct Get APi Call
				//jsonObject.put("UserWithRoles",getRequest(URLEndPoint+newJoinQuery));
				Utilities.logMessageInProcessLog("Query String..."+newJoinQuery);
				//update QueryOrHeaderParameters with user and condition
				((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetAccountWithAccountShare")).put("QueryOrHeaderParameters",newJoinQuery);

				jsonObject.put("AccountWithAccountShare",getDataFromSalesForceRestAPI("GetAccountWithAccountShare"));
				uid+=1;
			}		
			//System.out.println(jsonObject);
			Utilities.logMessageInProcessLog(jsonObject.toString());

		}
		//Send to Kafka Topic
		KafkaProducerCiti.SendSalesForceDataToKafkaTopic(jsonObject.toString());
	}


	//	//###########################Process Data Which is Received From SalesForce###################################

	public static void processSalesForceDataOld2(String salesForceData) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jsonObject=new JSONObject(salesForceData);
		String salesForceEntity=((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("entityName").toString();
		String callingGetApi=null;

		if (salesForceEntity.toUpperCase().equals("USER"))
			callingGetApi="GetUserAndUserRole";
		if (salesForceEntity.toUpperCase().equals("ACCOUNT"))
			callingGetApi="GetAccountAndAccountShare";

		Utilities.logMessageInProcessLog("\n################## < "+salesForceEntity.toUpperCase()+" > Changes#############################\n");
		JSONArray recordIds=(JSONArray)((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("recordIds");
		int uid=0;
		String inClauseRecords="";
		while (uid < recordIds.length()) {
			inClauseRecords+="'"+recordIds.get(uid)+"',";
			uid+=1;
		}

		inClauseRecords=inClauseRecords.substring(0, inClauseRecords.length()-1);

		//String URLEndPoint=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get("GetUserDataWithUserRole")).get("EndPointURL").toString(); //+salesForceEntity+"/"+recordIds.get(uid);
		String newJoinQuery=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).get("QueryOrHeaderParameters").toString()+"+and+"+salesForceEntity+".id+in("+inClauseRecords+")";	
		//Calling Direct Get APi Call
		//jsonObject.put("UserWithRoles",getRequest(URLEndPoint+newJoinQuery));
		Utilities.logMessageInProcessLog("Query String..."+newJoinQuery);
		//update QueryOrHeaderParameters with user and condition
		((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).put("QueryOrHeaderParameters",newJoinQuery);

		if (salesForceEntity.toUpperCase().equals("USER"))
			jsonObject.put("UserWithRoles",getDataFromSalesForceRestAPI(callingGetApi));
		if (salesForceEntity.toUpperCase().equals("ACCOUNT"))
			jsonObject.put("AccountWithAccountShare",getDataFromSalesForceRestAPI(callingGetApi));


		//System.out.println(jsonObject);
		Utilities.logMessageInProcessLog(jsonObject.toString());

		//Send to Kafka Topic and make string Java Compatable
		String dataToSendKafkaTopic=jsonObject.toString().replace("None","null").replace("True","true").replace("False","false");
		KafkaProducerCiti.SendSalesForceDataToKafkaTopic(dataToSendKafkaTopic);
	}

	//Modify Header Parameters with user in question 


	public static void ModifyGetRequestHeader(String callingGetApi,String inClauseRecords) {
		String newJoinQuery=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).get("QueryOrHeaderParameters").toString()+"+in("+inClauseRecords+")";	

		Utilities.logMessageInProcessLog("Query String..."+newJoinQuery);

		((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).put("QueryOrHeaderParameters",newJoinQuery);

	}

	
	//Modify Header and Reset Back To Original After Execution
	
	public static void ExecuteGetRestAPIAndResetBackHeader(String callingGetApi,String jsonKey,String inClauseRecords,JSONObject jsonObject) {
		//inClauseRecords="'00D3h000005WebuEAC'";
		String OriginalGetHeader=((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).get("QueryOrHeaderParameters").toString();
		ModifyGetRequestHeader(callingGetApi, inClauseRecords);			
		jsonObject.put(jsonKey,getDataFromSalesForceRestAPI(callingGetApi));
		((JSONObject)((JSONObject)((JSONObject)Utilities.configdata.get("SALESFORCE")).get("GETAPI")).get(callingGetApi)).put("QueryOrHeaderParameters",OriginalGetHeader);
		
	}
	//	//###########################Process Data Which is Received From SalesForce###################################

	public static void processSalesForceData(String salesForceData) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jsonObject=new JSONObject(salesForceData);
		String salesForceEntity=((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("entityName").toString();



		Utilities.logMessageInProcessLog("\n################## < "+salesForceEntity.toUpperCase()+" > Changes#############################\n");
		JSONArray recordIds=(JSONArray)((JSONObject)((JSONObject)jsonObject.get("payload")).get("ChangeEventHeader")).get("recordIds");
		int uid=0;
		String inClauseRecords="";
		while (uid < recordIds.length()) {
			inClauseRecords+="'"+recordIds.get(uid)+"',";
			uid+=1;
		}

		inClauseRecords=inClauseRecords.substring(0, inClauseRecords.length()-1);

		if (salesForceEntity.toUpperCase().equals("USER")) {
			//..GetUserAndUserRole			
			ExecuteGetRestAPIAndResetBackHeader("GetUserAndUserRole", "UserAndUserRole",inClauseRecords,jsonObject);
			
			//..GetAccountAndAccountShare			
			ExecuteGetRestAPIAndResetBackHeader("GetAccountAndAccountShare", "AccountAndAccountShare",inClauseRecords,jsonObject);

			//..GetGroupMemberAndGroup					
			ExecuteGetRestAPIAndResetBackHeader("GetGroupMemberAndGroup", "GroupMemberAndGroup",inClauseRecords,jsonObject);
			
			//System.out.println(jsonObject);
			Utilities.logMessageInProcessLog(jsonObject.toString());
                
			//Send to Kafka Topic and make string Java Compatable
			String dataToSendKafkaTopic=jsonObject.toString().replace("None","null").replace("True","true").replace("False","false");
			KafkaProducerCiti.SendSalesForceDataToKafkaTopic(dataToSendKafkaTopic);
		}
		
	}

	//	//###########################Process Data Which is Received From SalesForce Platform Event###################################

	public static void processSalesForcePlatformEventData(String salesForceData) {
		Utilities.logMessageInProcessLog("Calling.....< "+(new Exception().getStackTrace()[0].getMethodName())+" >");
		JSONObject jsonObject=new JSONObject(salesForceData);
		
		Utilities.logMessageInProcessLog("\n################## < "+salesForcePlatformEvent.toUpperCase()+" > Changes#############################\n");
            
		//Send to Kafka Topic and make string Java Compatable
		String dataToSendKafkaTopic=jsonObject.toString().replace("None","null").replace("True","true").replace("False","false");
		KafkaProducerCiti.SendSalesForceDataToKafkaTopic(dataToSendKafkaTopic);
		
		
	}

	
	static JSONArray GetCanonicalData(JSONObject jsonData) {
		JSONArray jsonArrayData= (JSONArray)jsonData.get("records");
		
		while ((boolean)jsonData.get("done")!=true) {
			
		}
			
		return jsonArrayData;
	}
	//
	//	//##################################Main Function Area ##################################
	//
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SalesForceConnect salesForceConnect=new SalesForceConnect();
		try {
			
			String pyCommand=((JSONObject)Utilities.configdata.get("SYSTEM_PARAMETERS")).get("EXECUTE_PYTHON_HDFS_LOAD").toString() +" "+"'{\"javakeycmd\":\"javadata\"}'";
			Utilities.logMessageInProcessLog("Laoding Data into HDFS....."+pyCommand);
			Process p = Runtime.getRuntime().exec(pyCommand);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Connection connection=Utilities.getDataBaseConnection("MYSQL");
//		//Utilities.getQueryResult(connection, "Select code,name,region,population from Country where population=11669000");
//		Utilities.getQueryResult(connection, "Select * from city where countrycode='AFG'");
//		BasicTextEncryptor k=Utilities.initEncryptDecrypt();
//		String encrypt=Utilities.ecryptPassword(k,"mypasword");
//		String dencrypt=Utilities.decryptPassword(k,encrypt);
//		System.out.print(encrypt+"   "+dencrypt);
		
		
		//System.out.println(getTime�nFormat("yyyy-MM-dd HH:mm:ss.SSS"));
		//System.out.println(getTime�nFormat("yyyyMMddHHmmss"));
		//System.out.println(SalesForceConnect.getRequest("https://usereaddy-fsc-dev-ed.my.salesforce.com/services/data/v52.0/query/?q=SELECT+Name,Email,UserRoleId,ProfileID,Phone+FROM+User").toString(4));
		
		JSONObject outData=getDataFromSalesForceRestAPI("GetUserDetail");
			//System.out.println(outData.toString(4));
			System.out.println(GetCanonicalData(outData).toString(4));
		//		salesForceConnect.Utilities.logMessageInProcessLog(outData.toString());
		//System.out.println(GetJsonValue(Utilities.configdata.toString(),"CREDENTIAL"));


		/*
		 * try { TimeUnit.SECONDS.sleep(1); } catch (InterruptedException ie) {
		 * Thread.currentThread().interrupt(); }
		 */

		//	String jsondata= "{			    \"payload\": {			        \"Name\": {			           \"FirstName\": \"KkJava13455\"			        }	    }			} }";

		//JSONObject k=new JSONObject(jsondata);
		//System.out.print(k.get("payload"));
	}	
}
//mvn clean package
//java -classpath  target\citi-connector-0.0.1-SNAPSHOT-phat.jar com.salesforce.citi.connector.execute.SalesForceStreamCDCToken

