package com.salesforce.citi.connector.execute;
import java.util.concurrent.TimeoutException;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQuery;



public class KafkaConsumerHDFS {
	KafkaConsumerHDFS(){
		SparkSession spark = SparkSession.builder()
				.appName("KafkaConsumer")
				.master("local[*]")
				.getOrCreate();

		Dataset<org.apache.spark.sql.Row> df = spark.readStream()
				.format("kafka")
				.option("kafka.bootstrap.servers", "localhost:9092")
				.option("subscribe", "salesforceTCRM")
				.load()
				.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)");
		df.printSchema();
		
		try {
			StreamingQuery ds = df
					   .writeStream()
					  .queryName("memselct")
					  .outputMode("append")
					  .format("console")
					  .start();					
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new KafkaConsumerHDFS();
	}
	
}
