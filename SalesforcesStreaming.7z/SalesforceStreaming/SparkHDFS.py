from pyspark.sql.types import *
from pyspark.sql import SparkSession
from Utilities import *

def WriteCSVDataToHDFS(data):
    spark = SparkSession.builder.appName("Stremaing_SalesForceToHDFS").getOrCreate()        
    spark.sparkContext.setLogLevel("WARN")
    
    LocalFileName=configdata['SYSTEM_PARAMETERS']['LOCAL_FILE_PATH']+"KafkaData.json"
    with open(LocalFileName,'w') as json_file:
        json_file.write(str(data).replace("'",'"'))

    df = spark.read.csv(LocalFileName)
    df.show()
    #df.write.csv("hdfs://localhost:9000/KafkaSalesData/example.csv")
    Index=GetItemIndex(configdata['SEARCH_STRING_FOR_INDEX']['HDFS_SERARCH_1']) 
    df.write.csv(configdata['HDFS'][Index]['URL']+configdata['HDFS'][Index]['HDFS_FILE_PATH']+"FileFromSparkCSV/"+datetime.datetime.now().strftime("%Y/%m/%d/%H%M%S"))
    #print(configdata)

def WriteJsonDataToHDFS(data):
    spark = SparkSession.builder.appName("Stremaing_SalesForceToHDFS").getOrCreate()        
    spark.sparkContext.setLogLevel("WARN")
    
    LocalFileName=configdata['SYSTEM_PARAMETERS']['LOCAL_FILE_PATH']+"KafkaData.json"
    with open(LocalFileName,'w') as json_file:
        json_file.write(str(data).replace("'",'"').replace("None",'null').replace("True",'true').replace("False",'false'))

    df = spark.read.json(LocalFileName)
    #df.show()
    #df.write.csv("hdfs://localhost:9000/KafkaSalesData/example.csv")
    Index=GetItemIndex(configdata['SEARCH_STRING_FOR_INDEX']['HDFS_SERARCH_1']) 
    df.write.json(configdata['HDFS'][Index]['URL']+configdata['HDFS'][Index]['HDFS_FILE_PATH']+data['payload']['ChangeEventHeader']['entityName']+datetime.datetime.now().strftime("_%Y%m%d%H%M%S"))

    df.write.json(configdata['HDFS'][Index]['URL']+configdata['HDFS'][Index]['HDFS_FILE_PATH']+data['payload']['ChangeEventHeader']['entityName']+datetime.datetime.now().strftime("/%Y/%m/%d/%H%M%S"))

    #print(configdata)

###execuet liek this c:\Python\Lib\site-packages\pyspark\bin\spark-submit  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.2.0  SparkHDFS.py/KafkaConsumerStreamCDCHDFS

def StreamDataToHDFS():      
    spark = SparkSession.builder.appName("Stremaing_SalesForceToHDFS").getOrCreate()        
    spark.sparkContext.setLogLevel("WARN")
    from pyspark.sql.functions import explode
    from pyspark.sql.functions import split
    print("Streaming Process...."+eval(configdata['KAFKA'][0]['BOOTSTRAP_SERVERS'])[0])
    Index=GetItemIndex(configdata['SEARCH_STRING_FOR_INDEX']['KAFKA_1'])
    df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", eval(configdata['KAFKA'][Index]['BOOTSTRAP_SERVERS'])[0]) \
    .option("subscribe", configdata['KAFKA'][Index]['TOPIC']) \
    .option("includeHeaders", "true")\
    .option("startingOffsets","latest")\
    .load()    
    
    #df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)", "headers")
    df.selectExpr("CAST(decode(key,'UTF-8') AS STRING)", "CAST(decode(value,'UTF-8') AS STRING)", "headers")
    #print("before hdfs...")
    #df.show(10,False)
    Index=GetItemIndex(configdata['SEARCH_STRING_FOR_INDEX']['HDFS_SERARCH_1']) 
    
    query1 = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)").writeStream.queryName("DataFromSalesFroce").outputMode("append").format("memory").start()
    query = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)").writeStream.queryName("DataFromSalesFroce1").outputMode("append").format("json").option("path", configdata['HDFS'][Index]['URL']+configdata['HDFS'][Index]['HDFS_FILE_PATH']+"FromJavaKafkaHDFS").option("checkpointLocation", configdata['HDFS'][Index]['URL']+"/tmp/checkpoint").start()
    while(1):
        
        #df=spark.sql("select decode(key,'UTF-8') ,decode(value,'UTF-8') from DataFromSalesFroce")
        df=spark.sql("select key,value from DataFromSalesFroce")
        df.show(10,False)
        print("vaia print"+str(df.collect())) 
        time.sleep(5)
        query.awaitTermination()
        query1.awaitTermination()
    
 
#WriteJsonDataToHDFS('{"name":"Kamlesh"}')
#StreamDataToHDFS()
#WriteCSVDataToHDFS("name,Kamlesh") 